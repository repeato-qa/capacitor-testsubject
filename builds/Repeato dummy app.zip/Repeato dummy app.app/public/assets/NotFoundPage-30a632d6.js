import{j as o}from"./vendor-75aa3432.js";import{P as r}from"./ProdErrorPage-6b028ce8.js";function a(){return o.jsx(r,{text:"Page not found.",canRefresh:!1})}export{a as default};
