import{j as r}from"./vendor-75aa3432.js";import{P as t}from"./ProdErrorPage-6b028ce8.js";function n(){return r.jsx(t,{text:"Something went wrong.",canRefresh:!0})}export{n as default};
